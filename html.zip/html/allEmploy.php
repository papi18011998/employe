<?php
 session_start();
 include('base.php'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>Liste des employés</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="styleCal.css">
</head>
<body style="background-image: url('img/inf.jpeg'); background-size:cover;">
	<?php 
		if (array_key_exists("erreur", $_SESSION)) {?>
		 	<div class="alert alert-danger">
		 		<?php print_r(implode("<br/>", $_SESSION['erreur']));
		 		unset($_SESSION['erreur']); ?>
		 	</div> 	 
	<?php }?> 
	<?php 
		if (array_key_exists("ok", $_SESSION)) {?>
		 	<div class="alert alert-success">
		 		<?php print_r(implode("<br/>", $_SESSION['ok']));
		 		unset($_SESSION['ok']); ?>
		 	</div> 	 
	<?php }?>
	 
	<div class="global col-md-12">
		<center>
		<div class="addContain col-md-10" style="padding:3%;">
			<div class="form-group col-md-5" style="float: left;">
				<input type="search" name="matSearch" placeholder="EM-0000" class="form-control">
				<input type="submit" name="rechercher" placeholder="Rechercher" class="btn btn-info" >
			</div>
			<div class="col-md-7" style="float: left;">
				<?php 
					$countBD=0;
					$lastMat='';
					$sqlCount="SELECT * FROM employe";
					$reqCountTable=$pdo->prepare($sqlCount);
					$reqCountTable->execute([]);
					while ($donneCount=$reqCountTable->fetch()) {
						$countBD++;
						$lastMat=$donneCount['matricule'];
					}
				?>
				<span style="margin-right:2%;">Nombre d'employés : <?php  echo '<span style="color:red; font-weight: bolder;">'.$countBD.'</span>'; ?></span>
				<span>Dernier matricule enregistré : <?php  echo '<span style="color:red; font-weight: bolder;">'.$lastMat.'</span>'; ?></span>
			</div>
			<table class="table-striped tb" >
				<tr>
					<td>Matricule</td>
					<td>Prénom(s)</td>
					<td>Nom</td>
					<td>Date de Naissance</td>
					<td>Salaire</td>
					<td>Téléphone</td>
					<td>Email</td>
					<td>Action</td>
				</tr>
				<?php 
					$sqlRecueilTable="SELECT * FROM employe";
					$reqRecueilTable=$pdo->prepare($sqlRecueilTable);
					$reqRecueilTable->execute([]);
					while ($donneRecueilli=$reqRecueilTable->fetch()) {?>
						<tr>
							<td><?php echo $donneRecueilli['matricule']; ?></td>
							<td><?php echo $donneRecueilli['prenom']; ?></td>
							<td><?php echo $donneRecueilli['nom']; ?></td>
							<td><?php echo $donneRecueilli['dateNais']; ?></td>
							<td><?php echo $donneRecueilli['sal']; ?></td>
							<td><?php echo $donneRecueilli['tel']; ?></td>
							<td><?php echo $donneRecueilli['email']; ?></td>
							<td>
									<form action="employUpdate.php" method="POST">
										<input type="hidden" name="id" value="<?php echo $donneRecueilli['id'];?>" readonly>
										<input type="submit" class=" btn btn-success " style='float:left;' value="Modifier" name="update" >
									</form>
									<form action="traitement.php" method="POST">
										<input type="hidden" name="idDelete" value="<?php echo $donneRecueilli['id'];?>" readonly>
										<input type="submit" class="btn btn-danger " style='float:left;' value="effacer" name="delete" >
									</form>
							</td>
						</tr>
					<?php } ?>
			</table>
		</div>
		</center>
	</div>
</body>
</html>