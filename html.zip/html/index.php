<?php session_start();
	  include('base.php');
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Bienvenue dans la page de gestion des employés</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="styleCal.css">
</head>
<body style="background-image: url('img/inf.jpeg'); background-size:cover;">
	<?php
		if (array_key_exists("erreur", $_SESSION)) {?>
		 	<div class="alert alert-danger">
		 		<?php print_r(implode("<br/>", $_SESSION['erreur']));
		 		unset($_SESSION['erreur']); ?>
		 	</div> 	 
		 <?php } 
		 if (array_key_exists("okInsert", $_SESSION)) {?>
		 	<div class="alert alert-success">
		 		<?php print_r(implode("<br/>", $_SESSION['okInsert']));
		 		unset($_SESSION['okInsert']); ?>
		 	</div> 	 
		 <?php } 
		 $sqlSelect="SELECT id FROM employe";
		 $reqSelect=$pdo->prepare($sqlSelect);
		 $reqSelect->execute();
		 $i=0;
		 while ($donne=$reqSelect->fetch()) {
		 	$i++;
		 }
		 echo $i;
	?>
	<div class="global col-md-12">
		<center>
		<div class=" col-md-8">
			<form action="traitement.php" method="post">
				<div class="topForm col-md-12">
					<div class="form-group">
					<h3 class="title" style="text-decoration:underline;"><center>Ajout d'employés</center></h3>
						<label for="">Matricule</label>
						<?php $i++?>
						<input type="text" name="matricule" class="form-control" value="<?php echo 'EM-0000'.$i;?>" readonly>
					</div>
				</div>
				<div class="leftForm col-md-6">
					<div class="form-group">
						<label for="">Prénom</label>
						<input type="text" name="prenom" class="form-control">
					</div>
					<div class="form-group">
						<label for="">Nom</label>
						<input type="text" name="nom" class="form-control">
					</div>
					<div class="form-group">
						<label for="">Date de Naissance</label>
						<input type="date" name="dateNais" class="form-control">
					</div>
				</div>
				<div class="rightForm col-md-6">
					<div class="form-group">
						<label for="">Salaire</label>
						<input type="number" name="sal" class="form-control">
					</div>
					<div class="form-group">
						<label for="">Téléphone</label>
						<input type="tel" name="tel" class="form-control">
					</div>
					<div class="form-group">
						<label for="">Email</label>
						<input type="email" name="email" class="form-control">
					</div>
				</div>
				<div class="submitDiv col-md-12">
						<input type="submit" value="Enregistrer" class="btn btn-success col-md-3" name="enregistrer">
						<input type="reset" value="Vider les Champs" class="btn btn-danger col-md-3">
						<a href="allEmploy.php" class="btn btn-warning col-md-3" >Liste des employés</a>
				</div>
			</form>
		</div>
		</center>
	</div>
</body>
</html>
