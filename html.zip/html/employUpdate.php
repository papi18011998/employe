<?php
	include('base.php'); 
	if (isset($_POST['update'])) {
		$sqlRecueilTable="SELECT * FROM employe WHERE id=?";
					$reqRecueilTable=$pdo->prepare($sqlRecueilTable);
					$reqRecueilTable->execute([$_POST['id']]);
					while ($donneRecueilli=$reqRecueilTable->fetch()) {
						$id=$donneRecueilli['id'];
						$prenom=$donneRecueilli['prenom'];
						$matricule=$donneRecueilli['matricule'];
						$dateNais=$donneRecueilli['dateNais'];
						$nom=$donneRecueilli['nom'];
						$email=$donneRecueilli['email'];
						$sal=$donneRecueilli['sal'];
						$tel=$donneRecueilli['tel'];
						} 
	}
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Espace de modificaion d'employés</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="styleCal.css">
</head>
<body style="background-image: url('img/inf.jpeg'); background-size:cover;">
	<div class="global col-md-12">
		<center>
		<div class=" col-md-8">
			<form action="traitement.php" method="post">
				<div class="topForm col-md-12">
					<div class="form-group">
					<h3 class="title" style="text-decoration:underline;"><center>Modification d'employés</center></h3>
						<label for="">Matricule</label>
						<input type="text" name="matriculeUpdate" class="form-control" value="<?php echo $matricule;?>" readonly>
					</div>
				</div>
				<div class="leftForm col-md-6">
					<div class="form-group">
						<label for="">Prénom</label>
						<input type="text" name="prenomUpdate" class="form-control" value="<?php echo $prenom;?>">
					</div>
					<div class="form-group">
						<label for="">Nom</label>
						<input type="text" name="nomUpdate" class="form-control" value="<?php echo $nom;?>">
					</div>
					<div class="form-group">
						<label for="">Date de Naissance</label>
						<input type="date" name="dateNaisUpdate" class="form-control" value="<?php echo $dateNais;?>">
					</div>
				</div>
				<div class="rightForm col-md-6">
					<div class="form-group">
						<label for="">Salaire</label>
						<input type="number" name="salUpdate" class="form-control" value="<?php echo $sal;?>">
					</div>
					<div class="form-group">
						<label for="">Téléphone</label>
						<input type="tel" name="telUpdate" class="form-control" value="<?php echo $tel;?>">
					</div>
					<div class="form-group">
						<label for="">Email</label>
						<input type="email" name="emailUpdate" class="form-control" value="<?php echo $email;?>">
					</div>
				</div>
				<div class="submitDiv col-md-12">
						<input type="submit" value="Modifier" class="btn btn-success col-md-5" name="modifier">
						<input type="reset" value="Vider les Champs" class="btn btn-danger col-md-5">
				</div>
			</form>
		</div>
		</center>
	</div>
</body>
</html>
