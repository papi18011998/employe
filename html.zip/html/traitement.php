<?php
	session_start();
	$erreur=[];
	$succesupdate=[];
	$succesinsert=[];
	if (isset($_POST['enregistrer'])) {
		
		if (empty($_POST['prenom'])) {
				$erreur['prenom']="Le prénom est un champ obligatoire";
		 }
		if (empty($_POST['nom'])) {
			$erreur['nom']="Le nom est un champ obligatoire";
		 }
		if (empty($_POST['dateNais'])) {
			$erreur['dateNais']="La date de naissance est un champ obligatoire";
		 }
		if (empty($_POST['sal'])) {
			$erreur['sal']="Le salaire est un champ obligatoire";
		}
		if (empty($_POST['tel'])) {
			$erreur['tel']="Le telephone est un champ obligatoire";
		 }
		if (empty($_POST['email'])) {
			$erreur['email']="L'email est un champ obligatoire";
		 }
		if (!(filter_var($_POST['email'],FILTER_VALIDATE_EMAIL))) {
			$erreur['email']="Le format de l'email est incorrect";
		}
		if ($_POST['sal']< 25000 || $_POST['sal']>2000000) {
			
			$erreur['sal']="Le salaire doit être entre 25000 et 2000000";
		}
		if (!empty($erreur)) {
			$_SESSION['erreur']=$erreur;
			header("location:index.php");
		}else{
			include('base.php');
			$sal=$_POST['sal'];
			$prenom=trim($_POST['prenom']);
			$nom=trim($_POST['nom']);
			$tel=$_POST['tel'];
			$email=trim($_POST['email']);
			$dateNais=$_POST['dateNais'];
			$matricule=$_POST['matricule'];
			$sqlInsert="INSERT INTO employe VALUES(null,?,?,?,?,?,?,?)";
			$req=$pdo->prepare($sqlInsert);
			$req->execute([$matricule,$prenom,$nom,$dateNais,$sal,$tel,$email]);
			$succesinsert['succes']="Employé ajouté avec succés";
			$_SESSION['okInsert']=$succesinsert;
			header("location:index.php");
		}
	}
	if (isset($_POST['modifier'])) {
		if (empty($_POST['prenomUpdate'])) {
				$erreur['prenomUpdate']="Le prénom est un champ obligatoire";
		 }
		if (empty($_POST['nomUpdate'])) {
			$erreur['nomUpdate']="Le nom est un champ obligatoire";
		 }
		if (empty($_POST['dateNaisUpdate'])) {
			$erreur['dateNaisUpdate']="La date de naissance est un champ obligatoire";
		 }
		if (empty($_POST['salUpdate'])) {
			$erreur['salUpdate']="Le salaire est un champ obligatoire";
		}
		if (empty($_POST['telUpdate'])) {
			$erreur['telUpdate']="Le telephone est un champ obligatoire";
		 }
		if (empty($_POST['emailUpdate'])) {
			$erreur['emailUpdate']="L'email est un champ obligatoire";
		 }
		if (!(filter_var($_POST['emailUpdate'],FILTER_VALIDATE_EMAIL))) {
			$erreur['emailUpdate']="Le format de l'email est incorrect";
		}
		if ($_POST['salUpdate']< 25000 || $_POST['salUpdate']>2000000) {
			
			$erreur['salUpdate']="Le salaire doit être entre 25000 et 2000000";
		}
		if (!empty($erreur)) {
			$_SESSION['erreur']=$erreur;
			header("location:allEmploy.php");
		}else{
			include('base.php');
			$sal=$_POST['salUpdate'];
			$prenom=trim($_POST['prenomUpdate']);
			$nom=trim($_POST['nomUpdate']);
			$tel=$_POST['telUpdate'];
			$email=trim($_POST['emailUpdate']);
			$dateNais=$_POST['dateNaisUpdate'];
			$matricule=$_POST['matriculeUpdate'];
			$sqlInsert="UPDATE employe SET prenom=?,nom=?,dateNais=?,sal=?,tel=?,email=? WHERE matricule=?";
			$req=$pdo->prepare($sqlInsert);
			$req->execute([$prenom,$nom,$dateNais,$sal,$tel,$email,$_POST['matriculeUpdate']]);
			$succesupdate['change']="Employé modifié avec succés";
			$_SESSION['ok']=$succesupdate;
			header("location:allEmploy.php");	
		}
	}
	if (isset($_POST['delete'])) {
		include('base.php');
		$sqlInsert="DELETE  FROM employe WHERE id=?";
			$req=$pdo->prepare($sqlInsert);
			$req->execute([$_POST['idDelete']]);
			$succesupdate['change']="Employé supprimé avec succès";
			$_SESSION['ok']=$succesupdate;
			header("location:allEmploy.php");
	}
	?>
