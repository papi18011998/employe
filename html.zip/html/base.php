<?php
	try {
		$pdo= new PDO("mysql:home=127.0.0.1;dbname=base","root","");
	} catch (Exception $e) {
		echo "echec de connexion";
	}